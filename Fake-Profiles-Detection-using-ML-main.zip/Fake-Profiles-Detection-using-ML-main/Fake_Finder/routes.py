from flask import render_template, request, redirect, url_for, flash, jsonify, session
from app import app, db
from models import ProfileScan, User
from utils import validate_profile_url, get_platform_name, get_platform_icon
from api_connectors import SocialMediaAPIFactory
from ml_model import detector
from werkzeug.security import generate_password_hash, check_password_hash
import logging

logger = logging.getLogger(__name__)

@app.route('/')
def index():
    """Home page with the profile detection form"""
    return render_template('index.html')

@app.route('/about')
def about():
    """About page explaining how the system works"""
    return render_template('about.html')

@app.route('/dashboard')
def dashboard():
    """Dashboard showing recent scan history"""
    # Get all scans, order by most recent
    all_scans = ProfileScan.query.order_by(ProfileScan.scan_date.desc()).all()
    
    # Track unique URLs for counting
    seen_urls = set()
    
    # Get recent scans (including repeats) but limited to 20
    recent_scans = all_scans[:20]
    
    # Count unique profiles only
    for scan in all_scans:
        seen_urls.add(scan.profile_url)
    
    # Get unique counts for stats
    total_scans = len(seen_urls)  # Only count unique URLs
    
    # Count unique profiles by status
    unique_status_counts = {
        'fake': 0,
        'authentic': 0,
        'uncertain': 0
    }
    
    # Use the most recent result for each unique URL
    url_latest_scan = {}
    for scan in all_scans:
        if scan.profile_url not in url_latest_scan:
            url_latest_scan[scan.profile_url] = scan
    
    # Count based on latest scan for each unique profile
    for scan in url_latest_scan.values():
        if scan.is_fake is True:
            unique_status_counts['fake'] += 1
        elif scan.is_fake is False:
            unique_status_counts['authentic'] += 1
        else:
            unique_status_counts['uncertain'] += 1
    
    # Calculate platform stats using unique profiles only
    platform_stats = {}
    for platform in ['facebook', 'instagram', 'twitter', 'linkedin']:
        platform_scans = [scan for url, scan in url_latest_scan.items() 
                         if scan.platform == platform]
        if platform_scans:
            platform_stats[platform.capitalize()] = len(platform_scans)
    
    return render_template(
        'dashboard.html',
        recent_scans=recent_scans,  # Shows all recent scans including repeats
        total_scans=total_scans,    # Only unique profiles
        fake_profiles=unique_status_counts['fake'],
        authentic_profiles=unique_status_counts['authentic'],
        uncertain_profiles=unique_status_counts['uncertain'],
        platform_stats=platform_stats,
        get_platform_icon=get_platform_icon,
        get_platform_name=get_platform_name
    )

@app.route('/analyze', methods=['POST'])
def analyze_profile():
    """Process the profile URL and analyze it"""
    profile_url = request.form.get('profile_url', '').strip()

    # Validate the URL
    is_valid, error_message = validate_profile_url(profile_url)
    if not is_valid:
        flash(error_message, 'danger')
        return redirect(url_for('index'))

    # Determine platform from URL
    platform = None
    if 'facebook.com' in profile_url:
        platform = 'facebook'
    elif 'instagram.com' in profile_url:
        platform = 'instagram'
    elif 'twitter.com' in profile_url or 'x.com' in profile_url:
        platform = 'twitter'
    elif 'linkedin.com' in profile_url:
        platform = 'linkedin'
    else:
        flash("Unsupported platform selected.", 'danger')
        return redirect(url_for('index'))

    # Get profile data from the selected platform using SocialMediaAPIFactory (no scraping)
    profile_data = SocialMediaAPIFactory.get_profile_data(profile_url)
    if not profile_data:
        flash("Could not retrieve profile data. Please check the URL and try again.", 'danger')
        return redirect(url_for('index'))

    # Run the ML model prediction
    prediction_result = detector.predict(profile_data)

    # Create a new profile scan record
    new_scan = ProfileScan(
        profile_url=profile_url,
        platform=platform,
        is_fake=prediction_result['is_fake'],
        confidence_score=prediction_result['confidence'],
        feature_data={
            'feature_values': prediction_result['feature_values'],
            'feature_importance': prediction_result['feature_importance']
        }
    )
    
    db.session.add(new_scan)
    db.session.commit()
    
    # Store the scan ID in session for result retrieval
    session['last_scan_id'] = new_scan.id
    
    # Redirect to the result page
    return redirect(url_for('result', scan_id=new_scan.id))

@app.route('/result/<int:scan_id>')
def result(scan_id):
    """Display the analysis result for a specific scan"""
    # Get the scan details
    scan = ProfileScan.query.get_or_404(scan_id)
    
    # Get platform info
    platform_name = get_platform_name(scan.profile_url)
    platform_icon = get_platform_icon(scan.profile_url)
    
    # Extract feature data
    feature_values = scan.feature_data.get('feature_values', {})
    feature_importance = scan.feature_data.get('feature_importance', {})
    
    # Sort features by importance
    sorted_features = sorted(
        feature_importance.items(), 
        key=lambda x: x[1], 
        reverse=True
    )
    
    return render_template(
        'result.html',
        scan=scan,
        platform_name=platform_name,
        platform_icon=platform_icon,
        feature_values=feature_values,
        feature_importance=feature_importance,
        sorted_features=sorted_features
    )

@app.route('/login', methods=['GET', 'POST'])
@app.route('/signup', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        # Determine if this is a signup or login based on form fields
        if 'username' in request.form and 'email' in request.form:
            # Signup logic
            username = request.form['username']
            email = request.form['email']
            password = request.form['password']
            is_admin = request.form.get('is_admin', False)
            if User.query.filter_by(username=username).first():
                flash('Username already exists.', 'danger')
                return redirect(url_for('login'))
            if User.query.filter_by(email=email).first():
                flash('Email already exists.', 'danger')
                return redirect(url_for('login'))
            hashed_password = generate_password_hash(password, method='pbkdf2:sha256')
            new_user = User(username=username, email=email, password_hash=hashed_password, is_admin=is_admin, analysis_attempts=0)
            db.session.add(new_user)
            db.session.commit()
            # Store user info in session after signup
            session['user_id'] = new_user.id
            session['is_admin'] = new_user.is_admin
            flash('Signup successful! You are now logged in.', 'success')
            return redirect(url_for('index'))
        else:
            # Login logic
            username = request.form['username']
            password = request.form['password']
            user = User.query.filter_by(username=username).first()
            if user and check_password_hash(user.password, password):
                session['user_id'] = user.id
                session['is_admin'] = user.is_admin
                flash('Login successful!', 'success')
                return redirect(url_for('index'))
            flash('Invalid username or password.', 'danger')
            return redirect(url_for('login'))
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out.', 'success')
    return redirect(url_for('index'))

@app.route('/user_details')
def user_details():
    if 'user_id' not in session:
        flash('Please log in to view your profile.', 'danger')
        return redirect(url_for('login'))

    user = User.query.get(session['user_id'])
    if not user:
        flash('User not found.', 'danger')
        return redirect(url_for('index'))

    return render_template('user_details.html', user=user)

@app.route('/google-login')
def google_login():
    flash("Google login is not yet implemented.", "info")
    return redirect(url_for('login'))

@app.route('/feedback', methods=['POST'])
def feedback():
    from models import Feedback
    name = request.form.get('name', '').strip()
    email = request.form.get('email', '').strip()
    message = request.form.get('message', '').strip()
    if not name or not email or not message:
        flash('All fields are required for feedback.', 'danger')
        return redirect(url_for('index'))
    fb = Feedback(name=name, email=email, message=message)
    db.session.add(fb)
    db.session.commit()
    flash('Thank you for your feedback!', 'success')
    return redirect(url_for('index'))

@app.before_request
def restrict_access():
    if request.endpoint == 'analyze_profile' and 'user_id' in session:
        user = User.query.get(session['user_id'])
        if not user.is_admin:
            if user.analysis_attempts >= 3:
                flash('Access limit reached. Please log in again.', 'danger')
                return redirect(url_for('login'))
            user.analysis_attempts += 1
            db.session.commit()
    # Reset analysis_attempts on logout or new signup
    if request.endpoint == 'logout' or (request.endpoint == 'login' and request.method == 'POST' and 'username' in request.form and 'email' in request.form):
        if 'user_id' in session:
            user = User.query.get(session['user_id'])
            if user:
                user.analysis_attempts = 0
                db.session.commit()

@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404

@app.errorhandler(500)
def server_error(e):
    return render_template('500.html'), 500
