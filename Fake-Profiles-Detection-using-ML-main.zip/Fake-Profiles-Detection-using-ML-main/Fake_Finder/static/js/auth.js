document.addEventListener('DOMContentLoaded', function() {
    // Get the form container and toggle button
    const container = document.querySelector('.cont');
    const toggleBtn = document.querySelector('.img__btn');

    if (toggleBtn) {
        toggleBtn.addEventListener('click', function() {
            container.classList.toggle('s--signup');
        });
    }

    // Handle form submissions
    const loginForm = document.querySelector('.form.sign-in form');
    const signupForm = document.querySelector('.form.sign-up form');

    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            const emailInput = loginForm.querySelector('input[type="email"]');
            const passwordInput = loginForm.querySelector('input[type="password"]');
            
            if (!emailInput.value || !passwordInput.value) {
                e.preventDefault();
                alert('Please fill in all fields');
            }
        });
    }

    if (signupForm) {
        signupForm.addEventListener('submit', function(e) {
            const inputs = signupForm.querySelectorAll('input');
            let isEmpty = false;

            inputs.forEach(input => {
                if (!input.value) {
                    isEmpty = true;
                }
            });

            if (isEmpty) {
                e.preventDefault();
                alert('Please fill in all fields');
            }
        });
    }
});