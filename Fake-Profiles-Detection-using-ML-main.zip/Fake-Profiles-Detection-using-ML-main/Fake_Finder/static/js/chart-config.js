document.addEventListener('DOMContentLoaded', function() {
    // Platform Distribution Chart
    const platformChartElement = document.getElementById('platform-distribution-chart');
    if (platformChartElement) {
        const platformData = JSON.parse(platformChartElement.getAttribute('data-platforms'));
        const platforms = Object.keys(platformData);
        const counts = Object.values(platformData);
        
        const platformColors = {
            'Facebook': '#1877f2',
            'Instagram': '#e1306c',
            'Twitter': '#1da1f2',
            'Linkedin': '#0077b5'
        };
        
        const colors = platforms.map(platform => platformColors[platform] || '#7e57c2');
        
        new Chart(platformChartElement, {
            type: 'doughnut',
            data: {
                labels: platforms,
                datasets: [{
                    data: counts,
                    backgroundColor: colors,
                    borderColor: '#1e1e1e',
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'right',
                        labels: {
                            color: '#e0e0e0',
                            font: {
                                size: 14
                            },
                            padding: 20
                        }
                    },
                    tooltip: {
                        backgroundColor: '#1e1e1e',
                        titleColor: '#e0e0e0',
                        bodyColor: '#e0e0e0',
                        borderColor: '#333333',
                        borderWidth: 1,
                        padding: 15,
                        displayColors: true,
                        callbacks: {
                            label: function(context) {
                                const label = context.label || '';
                                const value = context.raw || 0;
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = Math.round((value / total) * 100);
                                return `${label}: ${value} (${percentage}%)`;
                            }
                        }
                    }
                },
                cutout: '65%',
                animation: {
                    animateScale: true,
                    animateRotate: true
                }
            }
        });
    }
    
    // Fake vs Authentic Chart
    const detectionChartElement = document.getElementById('fake-authentic-chart');
    if (detectionChartElement) {
        const fakeCount = parseInt(detectionChartElement.getAttribute('data-fake') || 0);
        const authenticCount = parseInt(detectionChartElement.getAttribute('data-authentic') || 0);
        
        new Chart(detectionChartElement, {
            type: 'pie',
            data: {
                labels: ['Fake Profiles', 'Authentic Profiles'],
                datasets: [{
                    data: [fakeCount, authenticCount],
                    backgroundColor: ['#cf6679', '#4caf50'],
                    borderColor: '#1e1e1e',
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            color: '#e0e0e0',
                            font: {
                                size: 14
                            },
                            padding: 20
                        }
                    },
                    tooltip: {
                        backgroundColor: '#1e1e1e',
                        titleColor: '#e0e0e0',
                        bodyColor: '#e0e0e0',
                        borderColor: '#333333',
                        borderWidth: 1,
                        padding: 15,
                        displayColors: true,
                        callbacks: {
                            label: function(context) {
                                const label = context.label || '';
                                const value = context.raw || 0;
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = Math.round((value / total) * 100);
                                return `${label}: ${value} (${percentage}%)`;
                            }
                        }
                    }
                },
                animation: {
                    animateScale: true,
                    animateRotate: true
                }
            }
        });
    }
    
    // Feature Importance Chart
    const featureChartElement = document.getElementById('feature-importance-chart');
    if (featureChartElement) {
        const featureData = JSON.parse(featureChartElement.getAttribute('data-features'));
        const features = Object.keys(featureData);
        const importances = Object.values(featureData);
        
        // Format feature names for better readability
        const formattedFeatures = features.map(feature => {
            return feature.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
        });
        
        // Sort by importance (descending)
        const sortedData = importances.map((imp, i) => ({
            feature: formattedFeatures[i],
            importance: imp
        })).sort((a, b) => b.importance - a.importance);
        
        new Chart(featureChartElement, {
            type: 'bar',
            data: {
                labels: sortedData.map(item => item.feature),
                datasets: [{
                    label: 'Feature Importance',
                    data: sortedData.map(item => item.importance),
                    backgroundColor: '#7e57c2',
                    borderColor: '#6a48b0',
                    borderWidth: 1
                }]
            },
            options: {
                indexAxis: 'y',
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: '#1e1e1e',
                        titleColor: '#e0e0e0',
                        bodyColor: '#e0e0e0',
                        borderColor: '#333333',
                        borderWidth: 1,
                        padding: 15,
                        callbacks: {
                            label: function(context) {
                                const value = context.raw || 0;
                                return `Importance: ${(value * 100).toFixed(2)}%`;
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        },
                        ticks: {
                            color: '#e0e0e0',
                            font: {
                                size: 12
                            }
                        }
                    },
                    x: {
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        },
                        ticks: {
                            color: '#e0e0e0',
                            font: {
                                size: 12
                            },
                            callback: function(value) {
                                return (value * 100).toFixed(0) + '%';
                            }
                        },
                        max: Math.max(...importances) * 1.1
                    }
                },
                animation: {
                    duration: 2000,
                    easing: 'easeOutQuart'
                }
            }
        });
    }
});
