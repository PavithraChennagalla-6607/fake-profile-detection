document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    var tooltips = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltips.map(function(tooltip) {
        return new bootstrap.Tooltip(tooltip);
    });
    
    // Form validation
    const profileForm = document.getElementById('profile-form');
    if (profileForm) {
        profileForm.addEventListener('submit', function(event) {
            // Show loading overlay
            const loadingOverlay = document.getElementById('loading-overlay');
            if (loadingOverlay) {
                loadingOverlay.classList.add('active');
            }
            
            // Basic validation
            const profileUrl = document.getElementById('profile-url').value.trim();
            
            if (!profileUrl) {
                event.preventDefault();
                showAlert('Please enter a profile URL.', 'danger');
                hideLoadingOverlay();
                return;
            }
            
            // URL validation
            if (!isValidUrl(profileUrl)) {
                event.preventDefault();
                showAlert('Please enter a valid URL.', 'danger');
                hideLoadingOverlay();
                return;
            }
            
            // Check if it's a supported social media URL
            const supportedPlatforms = [
                'facebook.com', 'fb.com',
                'instagram.com',
                'twitter.com', 'x.com',
                'linkedin.com'
            ];
            
            const isSupported = supportedPlatforms.some(platform => profileUrl.includes(platform));
            
            if (!isSupported) {
                event.preventDefault();
                showAlert('Unsupported social media platform. We support Facebook, Instagram, Twitter, and LinkedIn.', 'danger');
                hideLoadingOverlay();
                return;
            }
        });
    }
    
    // Animation for result pages
    const resultElement = document.querySelector('.result-card');
    if (resultElement) {
        resultElement.classList.add('fade-in');
    }
    
    // Animate the confidence meter on result page
    const confidenceMeter = document.querySelector('.confidence-meter-fill');
    if (confidenceMeter) {
        // Get the confidence value from the data attribute
        const confidenceValue = confidenceMeter.getAttribute('data-confidence');
        
        // Set initial width to 0
        confidenceMeter.style.width = '0%';
        
        // Animate after a delay
        setTimeout(() => {
            confidenceMeter.style.width = confidenceValue + '%';
        }, 300);
    }
    
    // Animate feature importance bars
    const featureBars = document.querySelectorAll('.feature-bar-fill');
    if (featureBars.length > 0) {
        featureBars.forEach((bar, index) => {
            const value = bar.getAttribute('data-value');
            
            // Set initial width to 0
            bar.style.width = '0%';
            
            // Animate with staggered delay
            setTimeout(() => {
                bar.style.width = (value * 100) + '%';
            }, 300 + (index * 100));
        });
    }
    
    // Show example buttons
    const exampleButtons = document.querySelectorAll('.example-btn');
    if (exampleButtons.length > 0) {
        exampleButtons.forEach(button => {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                const url = this.getAttribute('data-url');
                document.getElementById('profile-url').value = url;
            });
        });
    }
    
    // Scan history table row click
    const historyRows = document.querySelectorAll('.history-row');
    if (historyRows.length > 0) {
        historyRows.forEach(row => {
            row.addEventListener('click', function() {
                const scanId = this.getAttribute('data-scan-id');
                if (scanId) {
                    window.location.href = `/result/${scanId}`;
                }
            });
        });
    }
});

// Helper Functions

function showAlert(message, type) {
    // Hide any existing alerts
    const existingAlerts = document.querySelectorAll('.alert');
    existingAlerts.forEach(alert => {
        alert.remove();
    });
    
    // Create new alert
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
    alertDiv.role = 'alert';
    
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `;
    
    // Find the alert container and insert the alert
    const alertContainer = document.getElementById('alert-container');
    if (alertContainer) {
        alertContainer.appendChild(alertDiv);
    } else {
        // If no container, insert before the form
        const form = document.getElementById('profile-form');
        if (form) {
            form.parentNode.insertBefore(alertDiv, form);
        }
    }
    
    // Auto-dismiss after 5 seconds
    setTimeout(() => {
        alertDiv.classList.remove('show');
        setTimeout(() => {
            alertDiv.remove();
        }, 300);
    }, 5000);
}

function hideLoadingOverlay() {
    const loadingOverlay = document.getElementById('loading-overlay');
    if (loadingOverlay) {
        loadingOverlay.classList.remove('active');
    }
}

function isValidUrl(url) {
    try {
        new URL(url);
        return true;
    } catch (e) {
        return false;
    }
}

// Register service worker for offline functionality
if ('serviceWorker' in navigator) {
    window.addEventListener('load', function() {
        navigator.serviceWorker.register('/static/js/service-worker.js').then(function(registration) {
            console.log('ServiceWorker registration successful with scope: ', registration.scope);
        }, function(err) {
            console.log('ServiceWorker registration failed: ', err);
        });
    });
}
