import re
from urllib.parse import urlparse
import logging

logger = logging.getLogger(__name__)

def validate_profile_url(url):
    """
    Validate if the provided URL is a valid social media profile URL
    Returns:
    - (True, None) if valid
    - (False, error_message) if invalid
    """
    if not url:
        return False, "URL cannot be empty"
    
    # Check if URL has a valid format
    try:
        result = urlparse(url)
        if not all([result.scheme, result.netloc]):
            return False, "Invalid URL format"
    except Exception as e:
        logger.error(f"Error parsing URL: {e}")
        return False, "Invalid URL format"
    
    # Check if URL is from a supported social media platform
    supported_domains = [
        'facebook.com', 'fb.com',
        'instagram.com',
        'twitter.com', 'x.com',
        'linkedin.com'
    ]
    
    domain = result.netloc
    if 'www.' in domain:
        domain = domain.replace('www.', '')
        
    if not any(supported_domain in domain for supported_domain in supported_domains):
        return False, "Unsupported social media platform. We support Facebook, Instagram, Twitter, and LinkedIn."
    
    # Platform specific validation
    if 'facebook.com' in domain or 'fb.com' in domain:
        pattern = r'facebook\.com\/(?:profile\.php\?id=)?([^\/\?]+)'
        if not re.search(pattern, url):
            return False, "Invalid Facebook profile URL"
    
    elif 'instagram.com' in domain:
        pattern = r'instagram\.com\/([^\/\?]+)'
        if not re.search(pattern, url):
            return False, "Invalid Instagram profile URL"
    
    elif 'twitter.com' in domain or 'x.com' in domain:
        pattern = r'twitter\.com\/([^\/\?]+)'
        if not re.search(pattern, url):
            return False, "Invalid Twitter profile URL"
    
    elif 'linkedin.com' in domain:
        pattern = r'linkedin\.com\/in\/([^\/\?]+)'
        if not re.search(pattern, url):
            return False, "Invalid LinkedIn profile URL"
    
    return True, None

def get_platform_name(url):
    """Get the platform name from the URL"""
    domain = urlparse(url).netloc
    
    if 'facebook.com' in domain or 'fb.com' in domain:
        return "Facebook"
    elif 'instagram.com' in domain:
        return "Instagram"
    elif 'twitter.com' in domain or 'x.com' in domain:
        return "Twitter"
    elif 'linkedin.com' in domain:
        return "LinkedIn"
    else:
        return "Unknown Platform"

def get_platform_icon(url):
    """Get the platform icon class from the URL"""
    domain = urlparse(url).netloc
    
    if 'facebook.com' in domain or 'fb.com' in domain:
        return "fab fa-facebook"
    elif 'instagram.com' in domain:
        return "fab fa-instagram"
    elif 'twitter.com' in domain or 'x.com' in domain:
        return "fab fa-twitter"
    elif 'linkedin.com' in domain:
        return "fab fa-linkedin"
    else:
        return "fas fa-globe"
