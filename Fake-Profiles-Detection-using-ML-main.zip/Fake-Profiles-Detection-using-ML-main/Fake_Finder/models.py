from datetime import datetime
from app import db
from flask_login import UserMixin

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256))
    is_admin = db.Column(db.Boolean, default=False)
    analysis_attempts = db.Column(db.Integer, default=0)
    scans = db.relationship('ProfileScan', backref='user', lazy='dynamic')
    
    def __repr__(self):
        return f'<User {self.username}>'
    
    def reset_attempts(self):
        self.analysis_attempts = 0
        db.session.commit()

class ProfileScan(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    profile_url = db.Column(db.String(500), nullable=False)
    platform = db.Column(db.String(50), nullable=False)
    scan_date = db.Column(db.DateTime, default=datetime.utcnow)
    is_fake = db.Column(db.Boolean, nullable=True)
    confidence_score = db.Column(db.Float, nullable=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    
    # Features detected from the profile
    feature_data = db.Column(db.JSON, nullable=True)
    
    def __repr__(self):
        return f'<ProfileScan {self.profile_url}>'
    
    @property
    def formatted_date(self):
        return self.scan_date.strftime('%Y-%m-%d %H:%M:%S')
    
    @property
    def is_reported_fake(self):
        """Return True if spam_reports_count > 4, else False."""
        if self.feature_data and isinstance(self.feature_data, dict):
            reports = self.feature_data.get('spam_reports_count', 0)
            return reports > 4
        return False

    @property
    def prediction_text(self):
        # If reported as fake by more than 4 users, always consider as fake
        if self.is_reported_fake:
            return "Fake Profile (Reported by Users)"
        if self.is_fake is None:
            return "Unknown"
        return "Fake Profile" if self.is_fake else "Authentic Profile"
    
    @property
    def confidence_percent(self):
        if self.confidence_score is None:
            return 0
        return round(self.confidence_score * 100, 2)

class Feedback(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), nullable=False)
    message = db.Column(db.Text, nullable=False)
    submitted_at = db.Column(db.DateTime, default=datetime.utcnow)
