import re
from urllib.parse import urlparse

# Example API file for Fake Profile Detector
# Famous public accounts as demo examples (all data is fictionalized for demo purposes)

EXAMPLE_PROFILES = [
    # Facebook: Example User
    {
        'platform': 'facebook',
        'username': 'example_fb_user',
        'full_name': 'Example Facebook User',
        'profile_pic_url': '',
        'account_age_days': 7000,
        'followers_count': 1200,
        'following_count': 10,
        'posts_count': 50,
        'bio': 'Just another Facebook user.',
        'location': 'Sample City',
        'external_url': '',
        'spam_reports_count': 0,
        'creation_date': '2010-01-01',
        'is_fake': False,
        'confidence': 0.95
    },
    # Instagram: Example User
    {
        'platform': 'instagram',
        'username': 'example_ig_user',
        'full_name': 'Example Instagram User',
        'profile_pic_url': '',
        'account_age_days': 2000,
        'followers_count': 500,
        'following_count': 300,
        'posts_count': 100,
        'bio': 'Sharing my world.',
        'location': 'Sample Town',
        'external_url': '',
        'spam_reports_count': 0,
        'creation_date': '2018-05-10',
        'is_fake': False,
        'confidence': 0.93
    },
    # Twitter: Example User
    {
        'platform': 'twitter',
        'username': 'example_tw_user',
        'full_name': 'Example Twitter User',
        'profile_pic_url': '',
        'account_age_days': 1500,
        'followers_count': 800,
        'following_count': 400,
        'posts_count': 300,
        'bio': 'Tweeting about tech and life.',
        'location': 'Sampleville',
        'external_url': '',
        'spam_reports_count': 0,
        'creation_date': '2019-07-15',
        'is_fake': False,
        'confidence': 0.92
    },
    # LinkedIn: Example User
    {
        'platform': 'linkedin',
        'username': 'example_li_user',
        'full_name': 'Example LinkedIn User',
        'profile_pic_url': '',
        'account_age_days': 3000,
        'followers_count': 1000,
        'following_count': 200,
        'posts_count': 80,
        'bio': 'Professional in tech.',
        'location': 'Sample State',
        'external_url': '',
        'spam_reports_count': 0,
        'creation_date': '2016-03-20',
        'is_fake': False,
        'confidence': 0.94
    },
    # Fake Example: Giveaway Bot
    {
        'platform': 'twitter',
        'username': 'giveaway_bot_2025',
        'full_name': 'Giveaway Bot',
        'profile_pic_url': '',
        'account_age_days': 5,
        'followers_count': 10,
        'following_count': 5000,
        'posts_count': 1,
        'bio': 'Win big prizes! Click the link!',
        'location': '',
        'external_url': '',
        'spam_reports_count': 50,
        'creation_date': '2025-06-10',
        'is_fake': True,
        'confidence': 1.0
    },
    # Fake Example: Promo Page
    {
        'platform': 'facebook',
        'username': 'promo_page_2025',
        'full_name': 'Promo Page',
        'profile_pic_url': '',
        'account_age_days': 3,
        'followers_count': 3,
        'following_count': 2000,
        'posts_count': 0,
        'bio': 'Get your free gift now!',
        'location': '',
        'external_url': '',
        'spam_reports_count': 25,
        'creation_date': '2025-06-09',
        'is_fake': True,
        'confidence': 0.99
    },
    # Fake Example: Influencer Bot
    {
        'platform': 'instagram',
        'username': 'influencer_bot_2025',
        'full_name': 'Influencer Bot',
        'profile_pic_url': '',
        'account_age_days': 7,
        'followers_count': 100,
        'following_count': 10000,
        'posts_count': 2,
        'bio': 'DM for collab! #ad',
        'location': '',
        'external_url': '',
        'spam_reports_count': 15,
        'creation_date': '2025-06-05',
        'is_fake': True,
        'confidence': 0.98
    },
    # Uncertain Example: New User
    {
        'platform': 'facebook',
        'username': 'uncertain_fb_user',
        'full_name': 'Uncertain FB User',
        'profile_pic_url': '',
        'account_age_days': 2,
        'followers_count': 0,
        'following_count': 0,
        'posts_count': 0,
        'bio': '',
        'location': '',
        'external_url': '',
        'spam_reports_count': 0,
        'creation_date': '2025-06-11',
        'is_fake': None,
        'confidence': 0.5
    },
    # Uncertain Example: Private IG
    {
        'platform': 'instagram',
        'username': 'uncertain_ig_user',
        'full_name': '',
        'profile_pic_url': '',
        'account_age_days': 100,
        'followers_count': 20,
        'following_count': 30,
        'posts_count': 0,
        'bio': '',
        'location': '',
        'external_url': '',
        'spam_reports_count': 0,
        'creation_date': '2025-03-01',
        'is_fake': None,
        'confidence': 0.6
    },
    # Real: Facebook Business Page
    {
        'platform': 'facebook',
        'username': 'sample_business_fb',
        'full_name': 'Sample Business',
        'profile_pic_url': '',
        'account_age_days': 4000,
        'followers_count': 5000,
        'following_count': 20,
        'posts_count': 800,
        'bio': 'Official page of Sample Business.',
        'location': 'Business City',
        'external_url': 'https://samplebusiness.com',
        'spam_reports_count': 0,
        'creation_date': '2014-02-01',
        'is_fake': False,
        'confidence': 0.97
    },
    # Fake: Instagram Contest Bot
    {
        'platform': 'instagram',
        'username': 'contest_bot_ig',
        'full_name': 'Contest Bot',
        'profile_pic_url': '',
        'account_age_days': 4,
        'followers_count': 12,
        'following_count': 4000,
        'posts_count': 1,
        'bio': 'Follow to win! #contest',
        'location': '',
        'external_url': '',
        'spam_reports_count': 30,
        'creation_date': '2025-06-14',
        'is_fake': True,
        'confidence': 0.99
    },
    # Real: Twitter Journalist
    {
        'platform': 'twitter',
        'username': 'real_journalist',
        'full_name': 'Jane Reporter',
        'profile_pic_url': '',
        'account_age_days': 3200,
        'followers_count': 15000,
        'following_count': 800,
        'posts_count': 12000,
        'bio': 'News. Truth. Updates.',
        'location': 'Metro City',
        'external_url': '',
        'spam_reports_count': 0,
        'creation_date': '2016-08-20',
        'is_fake': False,
        'confidence': 0.98
    },
    # Fake: LinkedIn Job Scam
    {
        'platform': 'linkedin',
        'username': 'job_scam_li',
        'full_name': 'HR Recruiter',
        'profile_pic_url': '',
        'account_age_days': 10,
        'followers_count': 50,
        'following_count': 2000,
        'posts_count': 0,
        'bio': 'We are hiring! DM for details.',
        'location': '',
        'external_url': '',
        'spam_reports_count': 12,
        'creation_date': '2025-06-08',
        'is_fake': True,
        'confidence': 0.96
    },
    # Uncertain: Instagram New User
    {
        'platform': 'instagram',
        'username': 'newbie_ig',
        'full_name': 'New IG User',
        'profile_pic_url': '',
        'account_age_days': 1,
        'followers_count': 0,
        'following_count': 0,
        'posts_count': 0,
        'bio': '',
        'location': '',
        'external_url': '',
        'spam_reports_count': 0,
        'creation_date': '2025-06-18',
        'is_fake': None,
        'confidence': 0.5
    },
    # Real: LinkedIn Professional
    {
        'platform': 'linkedin',
        'username': 'pro_linkedin',
        'full_name': 'Alex Professional',
        'profile_pic_url': '',
        'account_age_days': 2500,
        'followers_count': 3000,
        'following_count': 500,
        'posts_count': 200,
        'bio': 'Tech leader and mentor.',
        'location': 'Tech Valley',
        'external_url': '',
        'spam_reports_count': 0,
        'creation_date': '2018-07-01',
        'is_fake': False,
        'confidence': 0.96
    },
    # Fake: Facebook Event Spammer
    {
        'platform': 'facebook',
        'username': 'event_spammer_fb',
        'full_name': 'Event Spammer',
        'profile_pic_url': '',
        'account_age_days': 6,
        'followers_count': 5,
        'following_count': 1000,
        'posts_count': 0,
        'bio': 'Join our event for free gifts!',
        'location': '',
        'external_url': '',
        'spam_reports_count': 18,
        'creation_date': '2025-06-12',
        'is_fake': True,
        'confidence': 0.97
    },
    # Real: Instagram Influencer
    {
        'platform': 'instagram',
        'username': 'real_influencer',
        'full_name': 'Real Influencer',
        'profile_pic_url': '',
        'account_age_days': 1800,
        'followers_count': 25000,
        'following_count': 500,
        'posts_count': 2000,
        'bio': 'Lifestyle | Travel | Fitness',
        'location': 'Global',
        'external_url': 'https://realinfluencer.com',
        'spam_reports_count': 0,
        'creation_date': '2020-07-10',
        'is_fake': False,
        'confidence': 0.99
    },
    # Fake: Twitter Crypto Scam
    {
        'platform': 'twitter',
        'username': 'crypto_scam_tw',
        'full_name': 'Crypto Giveaway',
        'profile_pic_url': '',
        'account_age_days': 2,
        'followers_count': 8,
        'following_count': 3000,
        'posts_count': 2,
        'bio': 'Send 1 ETH, get 2 ETH back!',
        'location': '',
        'external_url': '',
        'spam_reports_count': 40,
        'creation_date': '2025-06-17',
        'is_fake': True,
        'confidence': 1.0
    },
    # Uncertain: LinkedIn No Info
    {
        'platform': 'linkedin',
        'username': 'noinfo_li',
        'full_name': '',
        'profile_pic_url': '',
        'account_age_days': 3,
        'followers_count': 0,
        'following_count': 0,
        'posts_count': 0,
        'bio': '',
        'location': '',
        'external_url': '',
        'spam_reports_count': 0,
        'creation_date': '2025-06-15',
        'is_fake': None,
        'confidence': 0.5
    },
    # Real: Twitter Developer
    {
        'platform': 'twitter',
        'username': 'dev_twitter',
        'full_name': 'Dev User',
        'profile_pic_url': '',
        'account_age_days': 2200,
        'followers_count': 4000,
        'following_count': 1000,
        'posts_count': 5000,
        'bio': 'Building cool things.',
        'location': 'Silicon City',
        'external_url': '',
        'spam_reports_count': 0,
        'creation_date': '2019-06-01',
        'is_fake': False,
        'confidence': 0.97
    },
]

EXAMPLE_PROFILE_LINKS = {
    'real': 'https://twitter.com/jack',
    'fake1': 'https://facebook.com/giveaway_bot_2025',
    'fake2': 'https://instagram.com/influencer_bot_2025',
    'uncertain': 'https://instagram.com/uncertain_ig_user'
}

class SocialMediaAPI:
    def extract_username(self, url):
        raise NotImplementedError()

class FacebookAPI(SocialMediaAPI):
    def extract_username(self, url):
        pattern = r'facebook\.com/(?:profile.php\?id=)?([^/\?]+)'
        match = re.search(pattern, url)
        if match:
            return match.group(1)
        return None

class InstagramAPI(SocialMediaAPI):
    def extract_username(self, url):
        pattern = r'instagram\.com/([^/\?]+)'
        match = re.search(pattern, url)
        if match:
            return match.group(1)
        return None

class TwitterAPI(SocialMediaAPI):
    def extract_username(self, url):
        pattern = r'twitter\.com/([^/\?]+)'
        match = re.search(pattern, url)
        if match:
            return match.group(1)
        return None

class LinkedInAPI(SocialMediaAPI):
    def extract_username(self, url):
        pattern = r'linkedin\.com/in/([^/\?]+)'
        match = re.search(pattern, url)
        if match:
            return match.group(1)
        return None

class SocialMediaAPIFactory:
    @staticmethod
    def get_api_connector(url):
        domain = urlparse(url).netloc
        if 'facebook.com' in domain:
            return FacebookAPI()
        elif 'instagram.com' in domain:
            return InstagramAPI()
        elif 'twitter.com' in domain or 'x.com' in domain:
            return TwitterAPI()
        elif 'linkedin.com' in domain:
            return LinkedInAPI()
        else:
            return None

    @staticmethod
    def get_profile_data(url):
        domain = urlparse(url).netloc
        username = None
        platform = None
        if 'facebook.com' in domain:
            platform = 'facebook'
            username = FacebookAPI().extract_username(url)
        elif 'instagram.com' in domain:
            platform = 'instagram'
            username = InstagramAPI().extract_username(url)
        elif 'twitter.com' in domain or 'x.com' in domain:
            platform = 'twitter'
            username = TwitterAPI().extract_username(url)
        elif 'linkedin.com' in domain:
            platform = 'linkedin'
            username = LinkedInAPI().extract_username(url)
        else:
            return None
        for profile in EXAMPLE_PROFILES:
            if profile['platform'] == platform and profile['username'] == username:
                return profile
        return None

def get_example_profiles():
    """API endpoint simulation: return all example profiles"""
    return EXAMPLE_PROFILES
